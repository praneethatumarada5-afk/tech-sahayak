"""Tracking how far each user has got + practice sessions."""
from database import get_connection
import badges


def start_lesson(user_id, lesson_id):
    conn = get_connection()
    conn.execute("""
        INSERT INTO user_lesson_progress (user_id, lesson_id, status, started_at)
        VALUES (?,?, 'in_progress', datetime('now'))
        ON CONFLICT(user_id, lesson_id) DO NOTHING""", (user_id, lesson_id))
    conn.commit()
    conn.close()


def update_step(user_id, lesson_id, step_number):
    """Call each time the learner moves to a new step."""
    start_lesson(user_id, lesson_id)
    conn = get_connection()
    conn.execute("""UPDATE user_lesson_progress SET last_step_number=?
                    WHERE user_id=? AND lesson_id=? AND status<>'completed'""",
                 (step_number, user_id, lesson_id))
    conn.commit()
    conn.close()


def complete_lesson(user_id, lesson_id):
    start_lesson(user_id, lesson_id)
    conn = get_connection()
    conn.execute("""UPDATE user_lesson_progress SET status='completed'
                    WHERE user_id=? AND lesson_id=?""", (user_id, lesson_id))
    conn.commit()
    conn.close()
    return badges.check_and_award(user_id)


def get_user_progress(user_id):
    conn = get_connection()
    rows = conn.execute("SELECT * FROM v_lesson_progress_pct WHERE user_id=?",
                        (user_id,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_dashboard(user_id):
    conn = get_connection()
    row = conn.execute("SELECT * FROM v_user_dashboard WHERE user_id=?",
                       (user_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def start_practice(user_id, scenario_id):
    conn = get_connection()
    cur = conn.execute("INSERT INTO practice_sessions (user_id, scenario_id) "
                       "VALUES (?,?)", (user_id, scenario_id))
    conn.commit()
    sid = cur.lastrowid
    conn.close()
    return sid


def finish_practice(session_id, mistakes, hints_used, success):
    conn = get_connection()
    conn.execute("""UPDATE practice_sessions SET completed_at=datetime('now'),
                    mistakes=?, hints_used=?, is_success=? WHERE session_id=?""",
                 (mistakes, hints_used, int(success), session_id))
    conn.commit()
    conn.close()
