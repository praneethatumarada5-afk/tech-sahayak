"""User registration, login and profile."""
import hashlib
import hmac
import os
import sqlite3
from database import get_connection


def _hash_password(password, salt=None):
    salt = salt or os.urandom(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 200_000)
    return salt.hex() + ":" + digest.hex()


def _verify_password(password, stored):
    salt_hex, digest_hex = stored.split(":")
    check = _hash_password(password, bytes.fromhex(salt_hex)).split(":")[1]
    return hmac.compare_digest(check, digest_hex)


def register_user(full_name, password, phone=None, email=None,
                  language_id=1, age_group=None):
    """Returns the new user_id, or None if phone/email already exists."""
    conn = get_connection()
    try:
        cur = conn.execute(
            "INSERT INTO users (full_name, phone, email, password_hash, "
            "preferred_language_id, age_group) VALUES (?,?,?,?,?,?)",
            (full_name, phone, email, _hash_password(password),
             language_id, age_group))
        conn.commit()
        return cur.lastrowid
    except sqlite3.IntegrityError:
        return None
    finally:
        conn.close()


def login_user(password, phone=None, email=None):
    """Returns the user row (dict) if credentials are right, else None."""
    conn = get_connection()
    row = conn.execute(
        "SELECT * FROM users WHERE (phone = ? OR email = ?) AND is_active = 1",
        (phone, email)).fetchone()
    if row and _verify_password(password, row["password_hash"]):
        conn.execute("UPDATE users SET last_login_at = datetime('now') "
                     "WHERE user_id = ?", (row["user_id"],))
        conn.commit()
        conn.close()
        return dict(row)
    conn.close()
    return None


def set_language(user_id, language_id):
    conn = get_connection()
    conn.execute("UPDATE users SET preferred_language_id=? WHERE user_id=?",
                 (language_id, user_id))
    conn.commit()
    conn.close()


def set_skill_level(user_id, level):
    conn = get_connection()
    conn.execute("UPDATE users SET skill_level=? WHERE user_id=?",
                 (level, user_id))
    conn.commit()
    conn.close()
