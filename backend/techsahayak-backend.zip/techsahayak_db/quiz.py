"""Fetch quizzes and grade the learner's answers."""
from database import get_connection
import badges


def get_quiz_for_lesson(lesson_id, language_id=1):
    """Returns {quiz_id, pass_percentage, questions:[{..., options:[...]}]}"""
    conn = get_connection()
    quiz = conn.execute("SELECT * FROM quizzes WHERE lesson_id=?",
                        (lesson_id,)).fetchone()
    if not quiz:
        conn.close()
        return None
    result = {"quiz_id": quiz["quiz_id"],
              "pass_percentage": quiz["pass_percentage"], "questions": []}
    questions = conn.execute("""
        SELECT q.question_id, q.question_type, q.image_path, q.points,
               COALESCE(t.question_text, e.question_text) AS question_text
        FROM questions q
        LEFT JOIN question_translations t ON t.question_id=q.question_id AND t.language_id=?
        LEFT JOIN question_translations e ON e.question_id=q.question_id AND e.language_id=1
        WHERE q.quiz_id=?""", (language_id, quiz["quiz_id"])).fetchall()
    for q in questions:
        opts = conn.execute("""
            SELECT o.option_id,
                   COALESCE(t.option_text, e.option_text) AS option_text
            FROM options o
            LEFT JOIN option_translations t ON t.option_id=o.option_id AND t.language_id=?
            LEFT JOIN option_translations e ON e.option_id=o.option_id AND e.language_id=1
            WHERE o.question_id=?""", (language_id, q["question_id"])).fetchall()
        item = dict(q)
        item["options"] = [dict(o) for o in opts]  # is_correct NOT sent to client
        result["questions"].append(item)
    conn.close()
    return result


def submit_quiz(user_id, quiz_id, answers, language_id=1):
    """answers = {question_id: selected_option_id}
    Returns score, max_score, passed and per-question explanations."""
    conn = get_connection()
    score = max_score = 0
    details = []
    questions = conn.execute(
        "SELECT question_id, points FROM questions WHERE quiz_id=?",
        (quiz_id,)).fetchall()
    cur = conn.execute(
        "INSERT INTO quiz_attempts (user_id, quiz_id) VALUES (?,?)",
        (user_id, quiz_id))
    attempt_id = cur.lastrowid
    for q in questions:
        max_score += q["points"]
        chosen = answers.get(q["question_id"])
        correct = 0
        if chosen is not None:
            row = conn.execute(
                "SELECT is_correct FROM options WHERE option_id=? AND question_id=?",
                (chosen, q["question_id"])).fetchone()
            correct = 1 if row and row["is_correct"] else 0
        score += q["points"] * correct
        conn.execute("INSERT INTO attempt_answers VALUES (?,?,?,?)",
                     (attempt_id, q["question_id"], chosen, correct))
        exp = conn.execute("""
            SELECT COALESCE(t.explanation, e.explanation) AS explanation
            FROM questions q
            LEFT JOIN question_translations t ON t.question_id=q.question_id AND t.language_id=?
            LEFT JOIN question_translations e ON e.question_id=q.question_id AND e.language_id=1
            WHERE q.question_id=?""", (language_id, q["question_id"])).fetchone()
        details.append({"question_id": q["question_id"], "correct": bool(correct),
                        "explanation": exp["explanation"] if exp else None})
    # Setting score fires the trigger that computes 'passed'
    conn.execute("UPDATE quiz_attempts SET score=?, max_score=? WHERE attempt_id=?",
                 (score, max_score, attempt_id))
    # trigger only runs on INSERT, so compute 'passed' explicitly as well
    conn.execute("""UPDATE quiz_attempts SET passed = CASE WHEN max_score>0 AND
                    score*100.0/max_score >= (SELECT pass_percentage FROM quizzes
                    WHERE quiz_id=?) THEN 1 ELSE 0 END WHERE attempt_id=?""",
                 (quiz_id, attempt_id))
    passed = conn.execute("SELECT passed FROM quiz_attempts WHERE attempt_id=?",
                          (attempt_id,)).fetchone()["passed"]
    conn.commit()
    conn.close()
    new_badges = badges.check_and_award(user_id)
    return {"attempt_id": attempt_id, "score": score, "max_score": max_score,
            "passed": bool(passed), "details": details,
            "new_badges": new_badges}
