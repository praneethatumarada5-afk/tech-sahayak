"""Awards badges automatically based on the user's activity."""
from database import get_connection


def _award(conn, user_id, code):
    badge = conn.execute("SELECT badge_id, name, icon FROM badges WHERE code=?",
                         (code,)).fetchone()
    if not badge:
        return None
    cur = conn.execute("INSERT OR IGNORE INTO user_badges (user_id, badge_id) "
                       "VALUES (?,?)", (user_id, badge["badge_id"]))
    return dict(badge) if cur.rowcount else None   # None if already owned


def check_and_award(user_id):
    """Returns the list of badges newly earned in this call."""
    conn = get_connection()
    new = []
    completed = conn.execute(
        "SELECT COUNT(*) FROM user_lesson_progress WHERE user_id=? AND status='completed'",
        (user_id,)).fetchone()[0]
    if completed >= 1:
        new.append(_award(conn, user_id, "FIRST_LESSON"))
    passed_security = conn.execute("""
        SELECT COUNT(*) FROM quiz_attempts a
        JOIN quizzes q ON q.quiz_id=a.quiz_id
        JOIN lessons l ON l.lesson_id=q.lesson_id
        JOIN categories c ON c.category_id=l.category_id
        WHERE a.user_id=? AND a.passed=1 AND c.slug='cybersecurity'""",
        (user_id,)).fetchone()[0]
    if passed_security:
        new.append(_award(conn, user_id, "SAFE_SURFER"))
    paid = conn.execute("""
        SELECT COUNT(*) FROM practice_sessions s
        JOIN practice_scenarios p ON p.scenario_id=s.scenario_id
        JOIN lessons l ON l.lesson_id=p.lesson_id
        JOIN categories c ON c.category_id=l.category_id
        WHERE s.user_id=? AND s.is_success=1 AND c.slug='digital-payments'""",
        (user_id,)).fetchone()[0]
    if paid:
        new.append(_award(conn, user_id, "PAYMENT_PRO"))
    conn.commit()
    conn.close()
    return [b for b in new if b]


def get_user_badges(user_id):
    conn = get_connection()
    rows = conn.execute("""SELECT b.code, b.name, b.icon, ub.earned_at
        FROM user_badges ub JOIN badges b ON b.badge_id=ub.badge_id
        WHERE ub.user_id=?""", (user_id,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]
