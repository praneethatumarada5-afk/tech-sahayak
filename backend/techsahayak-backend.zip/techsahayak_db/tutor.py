"""Stores AI-tutor chat history. The AI teammate calls these functions."""
from database import get_connection


def start_conversation(user_id, language_id=1, lesson_id=None):
    conn = get_connection()
    cur = conn.execute("INSERT INTO tutor_conversations (user_id, lesson_id, "
                       "language_id) VALUES (?,?,?)",
                       (user_id, lesson_id, language_id))
    conn.commit()
    cid = cur.lastrowid
    conn.close()
    return cid


def save_message(conversation_id, sender, text):
    """sender must be 'user' or 'tutor'."""
    conn = get_connection()
    conn.execute("INSERT INTO tutor_messages (conversation_id, sender, "
                 "message_text) VALUES (?,?,?)", (conversation_id, sender, text))
    conn.commit()
    conn.close()


def get_history(conversation_id, limit=50):
    """Last N messages, oldest first, ready to feed back to the AI as context."""
    conn = get_connection()
    rows = conn.execute("""SELECT sender, message_text, created_at FROM (
            SELECT * FROM tutor_messages WHERE conversation_id=?
            ORDER BY message_id DESC LIMIT ?) ORDER BY message_id""",
                        (conversation_id, limit)).fetchall()
    conn.close()
    return [dict(r) for r in rows]
