"""Demo / smoke test. Run AFTER setup_db.py:  python test_db.py"""
import users, lessons, progress, quiz, tutor, badges

print("1. Register")
uid = users.register_user("Ramesh Kumar", "secret123", phone="9876543210", language_id=2)
print("   user_id =", uid)

print("2. Login:", bool(users.login_user("secret123", phone="9876543210")))
print("   Wrong password:", users.login_user("nope", phone="9876543210"))

print("3. Categories (Hindi):", [c["name"] for c in lessons.get_categories(2)])
print("4. Lessons (Hindi):", [l["title"] for l in lessons.get_lessons(2)])

print("5. UPI lesson unlocked?", lessons.is_lesson_unlocked(uid, 3))
for step in lessons.get_lesson_steps(1, 2):
    progress.update_step(uid, 1, step["step_number"])
print("   Steps read:", len(lessons.get_lesson_steps(1, 2)))
print("   New badges:", progress.complete_lesson(uid, 1))

print("6. Quiz")
q = quiz.get_quiz_for_lesson(4, 1)
question = q["questions"][0]
for o in question["options"]:
    print("   -", o["option_id"], o["option_text"])
result = quiz.submit_quiz(uid, q["quiz_id"], {question["question_id"]: 2})
print("   Result:", result["score"], "/", result["max_score"],
      "passed:", result["passed"], "badges:", result["new_badges"])

print("7. Tutor chat")
cid = tutor.start_conversation(uid, language_id=2, lesson_id=1)
tutor.save_message(cid, "user", "वाई-फ़ाई कैसे चालू करें?")
tutor.save_message(cid, "tutor", "सेटिंग्स खोलें और वाई-फ़ाई दबाएँ।")
print("   History:", len(tutor.get_history(cid)), "messages")

print("8. Dashboard:", progress.get_dashboard(uid))
print("   Badges:", [b["name"] for b in badges.get_user_badges(uid)])
print("\nALL GOOD")
