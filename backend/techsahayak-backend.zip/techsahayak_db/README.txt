TechSahayak - Database module
=============================
1. python setup_db.py   -> builds techsahayak.db from techsahayak.sql
2. python test_db.py    -> runs a demo of every function
Backend teammates:  import users, lessons, progress, quiz, tutor, badges
