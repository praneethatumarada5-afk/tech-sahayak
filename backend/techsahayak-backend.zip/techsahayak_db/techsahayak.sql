-- =====================================================================
-- TechSahayak : SQLite database schema
-- Run with:  sqlite3 techsahayak.db < techsahayak.sql
-- =====================================================================
PRAGMA foreign_keys = ON;

-- ---------------------------------------------------------------------
-- 1. LANGUAGES (multilingual support)
-- ---------------------------------------------------------------------
CREATE TABLE languages (
    language_id INTEGER PRIMARY KEY AUTOINCREMENT,
    code        TEXT NOT NULL UNIQUE,          -- 'en', 'hi', 'bn' ...
    name        TEXT NOT NULL,                 -- 'English'
    native_name TEXT NOT NULL,                 -- 'हिन्दी'
    is_active   INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1))
);

-- ---------------------------------------------------------------------
-- 2. USERS
-- ---------------------------------------------------------------------
CREATE TABLE users (
    user_id               INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name             TEXT NOT NULL,
    phone                 TEXT UNIQUE,
    email                 TEXT UNIQUE,
    password_hash         TEXT NOT NULL,        -- NEVER store plain passwords
    preferred_language_id INTEGER NOT NULL DEFAULT 1
                          REFERENCES languages(language_id),
    skill_level           TEXT NOT NULL DEFAULT 'beginner'
                          CHECK (skill_level IN ('beginner','intermediate','advanced')),
    age_group             TEXT CHECK (age_group IN ('under_18','18_30','31_50','51_65','65_plus')),
    created_at            TEXT NOT NULL DEFAULT (datetime('now')),
    last_login_at         TEXT,
    is_active             INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1)),
    CHECK (phone IS NOT NULL OR email IS NOT NULL)
);

-- ---------------------------------------------------------------------
-- 3. CATEGORIES (communication, payments, cybersecurity ...)
-- ---------------------------------------------------------------------
CREATE TABLE categories (
    category_id INTEGER PRIMARY KEY AUTOINCREMENT,
    slug        TEXT NOT NULL UNIQUE,
    icon        TEXT,
    sort_order  INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE category_translations (
    category_id INTEGER NOT NULL REFERENCES categories(category_id) ON DELETE CASCADE,
    language_id INTEGER NOT NULL REFERENCES languages(language_id),
    name        TEXT NOT NULL,
    description TEXT,
    PRIMARY KEY (category_id, language_id)
);

-- ---------------------------------------------------------------------
-- 4. LESSONS, STEPS (step-by-step visual tutorials)
-- ---------------------------------------------------------------------
CREATE TABLE lessons (
    lesson_id         INTEGER PRIMARY KEY AUTOINCREMENT,
    category_id       INTEGER NOT NULL REFERENCES categories(category_id),
    slug              TEXT NOT NULL UNIQUE,
    difficulty        TEXT NOT NULL DEFAULT 'beginner'
                      CHECK (difficulty IN ('beginner','intermediate','advanced')),
    estimated_minutes INTEGER NOT NULL DEFAULT 10 CHECK (estimated_minutes > 0),
    thumbnail_path    TEXT,
    is_published      INTEGER NOT NULL DEFAULT 1 CHECK (is_published IN (0,1)),
    created_at        TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE lesson_translations (
    lesson_id   INTEGER NOT NULL REFERENCES lessons(lesson_id) ON DELETE CASCADE,
    language_id INTEGER NOT NULL REFERENCES languages(language_id),
    title       TEXT NOT NULL,
    description TEXT,
    PRIMARY KEY (lesson_id, language_id)
);

-- Prerequisite lessons (e.g. "UPI payment" requires "Install an app")
CREATE TABLE lesson_prerequisites (
    lesson_id              INTEGER NOT NULL REFERENCES lessons(lesson_id) ON DELETE CASCADE,
    prerequisite_lesson_id INTEGER NOT NULL REFERENCES lessons(lesson_id) ON DELETE CASCADE,
    PRIMARY KEY (lesson_id, prerequisite_lesson_id),
    CHECK (lesson_id <> prerequisite_lesson_id)
);

CREATE TABLE lesson_steps (
    step_id     INTEGER PRIMARY KEY AUTOINCREMENT,
    lesson_id   INTEGER NOT NULL REFERENCES lessons(lesson_id) ON DELETE CASCADE,
    step_number INTEGER NOT NULL CHECK (step_number > 0),
    image_path  TEXT,                          -- screenshot / illustration
    audio_path  TEXT,                          -- optional voice guidance
    UNIQUE (lesson_id, step_number)
);

CREATE TABLE step_translations (
    step_id     INTEGER NOT NULL REFERENCES lesson_steps(step_id) ON DELETE CASCADE,
    language_id INTEGER NOT NULL REFERENCES languages(language_id),
    title       TEXT NOT NULL,
    instruction TEXT NOT NULL,
    PRIMARY KEY (step_id, language_id)
);

-- ---------------------------------------------------------------------
-- 5. PRACTICE ENVIRONMENTS (safe sandbox / simulations)
-- ---------------------------------------------------------------------
CREATE TABLE practice_scenarios (
    scenario_id   INTEGER PRIMARY KEY AUTOINCREMENT,
    lesson_id     INTEGER NOT NULL REFERENCES lessons(lesson_id) ON DELETE CASCADE,
    title         TEXT NOT NULL,
    scenario_type TEXT NOT NULL DEFAULT 'simulation'
                  CHECK (scenario_type IN ('simulation','drag_drop','fill_form','click_path')),
    config_json   TEXT,                        -- UI layout / expected actions as JSON
    CHECK (config_json IS NULL OR json_valid(config_json))
);

CREATE TABLE practice_sessions (
    session_id   INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id      INTEGER NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    scenario_id  INTEGER NOT NULL REFERENCES practice_scenarios(scenario_id),
    started_at   TEXT NOT NULL DEFAULT (datetime('now')),
    completed_at TEXT,
    mistakes     INTEGER NOT NULL DEFAULT 0,
    hints_used   INTEGER NOT NULL DEFAULT 0,
    is_success   INTEGER NOT NULL DEFAULT 0 CHECK (is_success IN (0,1))
);

-- ---------------------------------------------------------------------
-- 6. QUIZZES
-- ---------------------------------------------------------------------
CREATE TABLE quizzes (
    quiz_id         INTEGER PRIMARY KEY AUTOINCREMENT,
    lesson_id       INTEGER NOT NULL REFERENCES lessons(lesson_id) ON DELETE CASCADE,
    pass_percentage INTEGER NOT NULL DEFAULT 60 CHECK (pass_percentage BETWEEN 1 AND 100)
);

CREATE TABLE questions (
    question_id   INTEGER PRIMARY KEY AUTOINCREMENT,
    quiz_id       INTEGER NOT NULL REFERENCES quizzes(quiz_id) ON DELETE CASCADE,
    question_type TEXT NOT NULL DEFAULT 'single_choice'
                  CHECK (question_type IN ('single_choice','true_false','image_choice')),
    image_path    TEXT,
    points        INTEGER NOT NULL DEFAULT 1 CHECK (points > 0)
);

CREATE TABLE question_translations (
    question_id INTEGER NOT NULL REFERENCES questions(question_id) ON DELETE CASCADE,
    language_id INTEGER NOT NULL REFERENCES languages(language_id),
    question_text TEXT NOT NULL,
    explanation   TEXT,                        -- shown after answering
    PRIMARY KEY (question_id, language_id)
);

CREATE TABLE options (
    option_id   INTEGER PRIMARY KEY AUTOINCREMENT,
    question_id INTEGER NOT NULL REFERENCES questions(question_id) ON DELETE CASCADE,
    is_correct  INTEGER NOT NULL DEFAULT 0 CHECK (is_correct IN (0,1))
);

CREATE TABLE option_translations (
    option_id   INTEGER NOT NULL REFERENCES options(option_id) ON DELETE CASCADE,
    language_id INTEGER NOT NULL REFERENCES languages(language_id),
    option_text TEXT NOT NULL,
    PRIMARY KEY (option_id, language_id)
);

CREATE TABLE quiz_attempts (
    attempt_id   INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id      INTEGER NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    quiz_id      INTEGER NOT NULL REFERENCES quizzes(quiz_id),
    score        INTEGER NOT NULL DEFAULT 0,
    max_score    INTEGER NOT NULL DEFAULT 0,
    passed       INTEGER NOT NULL DEFAULT 0 CHECK (passed IN (0,1)),
    attempted_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE attempt_answers (
    attempt_id         INTEGER NOT NULL REFERENCES quiz_attempts(attempt_id) ON DELETE CASCADE,
    question_id        INTEGER NOT NULL REFERENCES questions(question_id),
    selected_option_id INTEGER REFERENCES options(option_id),
    is_correct         INTEGER NOT NULL DEFAULT 0 CHECK (is_correct IN (0,1)),
    PRIMARY KEY (attempt_id, question_id)
);

-- ---------------------------------------------------------------------
-- 7. LEARNING PROGRESS TRACKING
-- ---------------------------------------------------------------------
CREATE TABLE user_lesson_progress (
    user_id         INTEGER NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    lesson_id       INTEGER NOT NULL REFERENCES lessons(lesson_id) ON DELETE CASCADE,
    status          TEXT NOT NULL DEFAULT 'not_started'
                    CHECK (status IN ('not_started','in_progress','completed')),
    last_step_number INTEGER NOT NULL DEFAULT 0,
    started_at      TEXT,
    completed_at    TEXT,
    updated_at      TEXT NOT NULL DEFAULT (datetime('now')),
    PRIMARY KEY (user_id, lesson_id)
);

-- ---------------------------------------------------------------------
-- 8. AI TUTOR CHAT HISTORY
-- ---------------------------------------------------------------------
CREATE TABLE tutor_conversations (
    conversation_id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id         INTEGER NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    lesson_id       INTEGER REFERENCES lessons(lesson_id) ON DELETE SET NULL,
    language_id     INTEGER NOT NULL REFERENCES languages(language_id),
    started_at      TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE tutor_messages (
    message_id      INTEGER PRIMARY KEY AUTOINCREMENT,
    conversation_id INTEGER NOT NULL REFERENCES tutor_conversations(conversation_id) ON DELETE CASCADE,
    sender          TEXT NOT NULL CHECK (sender IN ('user','tutor')),
    message_text    TEXT NOT NULL,
    created_at      TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ---------------------------------------------------------------------
-- 9. BADGES / GAMIFICATION (motivates beginners)
-- ---------------------------------------------------------------------
CREATE TABLE badges (
    badge_id    INTEGER PRIMARY KEY AUTOINCREMENT,
    code        TEXT NOT NULL UNIQUE,          -- 'FIRST_LESSON', 'SAFE_SURFER'
    name        TEXT NOT NULL,
    description TEXT,
    icon        TEXT
);

CREATE TABLE user_badges (
    user_id   INTEGER NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    badge_id  INTEGER NOT NULL REFERENCES badges(badge_id),
    earned_at TEXT NOT NULL DEFAULT (datetime('now')),
    PRIMARY KEY (user_id, badge_id)
);

-- ---------------------------------------------------------------------
-- 10. INDEXES
-- ---------------------------------------------------------------------
CREATE INDEX idx_lessons_category    ON lessons(category_id);
CREATE INDEX idx_steps_lesson        ON lesson_steps(lesson_id, step_number);
CREATE INDEX idx_questions_quiz      ON questions(quiz_id);
CREATE INDEX idx_options_question    ON options(question_id);
CREATE INDEX idx_attempts_user       ON quiz_attempts(user_id, quiz_id);
CREATE INDEX idx_progress_user       ON user_lesson_progress(user_id, status);
CREATE INDEX idx_practice_user       ON practice_sessions(user_id);
CREATE INDEX idx_messages_conv       ON tutor_messages(conversation_id, created_at);

-- ---------------------------------------------------------------------
-- 11. TRIGGERS
-- ---------------------------------------------------------------------
-- Auto-set completed_at when a lesson becomes 'completed'
CREATE TRIGGER trg_progress_completed
AFTER UPDATE OF status ON user_lesson_progress
WHEN NEW.status = 'completed' AND OLD.status <> 'completed'
BEGIN
    UPDATE user_lesson_progress
    SET completed_at = datetime('now'), updated_at = datetime('now')
    WHERE user_id = NEW.user_id AND lesson_id = NEW.lesson_id;
END;

-- Auto-compute 'passed' on quiz attempts
CREATE TRIGGER trg_attempt_passed
AFTER INSERT ON quiz_attempts
BEGIN
    UPDATE quiz_attempts
    SET passed = CASE
        WHEN NEW.max_score > 0 AND
             (NEW.score * 100.0 / NEW.max_score) >=
             (SELECT pass_percentage FROM quizzes WHERE quiz_id = NEW.quiz_id)
        THEN 1 ELSE 0 END
    WHERE attempt_id = NEW.attempt_id;
END;

-- Update last_login on demand is done by the app; keep progress timestamp fresh
CREATE TRIGGER trg_progress_touch
AFTER UPDATE OF last_step_number ON user_lesson_progress
BEGIN
    UPDATE user_lesson_progress
    SET updated_at = datetime('now')
    WHERE user_id = NEW.user_id AND lesson_id = NEW.lesson_id;
END;

-- ---------------------------------------------------------------------
-- 12. VIEWS (ready-made queries for the backend / dashboard)
-- ---------------------------------------------------------------------
-- Per-user, per-lesson progress with percentage complete
CREATE VIEW v_lesson_progress_pct AS
SELECT  p.user_id,
        p.lesson_id,
        p.status,
        p.last_step_number,
        (SELECT COUNT(*) FROM lesson_steps s WHERE s.lesson_id = p.lesson_id) AS total_steps,
        CASE WHEN p.status = 'completed' THEN 100
             ELSE ROUND(100.0 * p.last_step_number /
                  NULLIF((SELECT COUNT(*) FROM lesson_steps s WHERE s.lesson_id = p.lesson_id),0))
        END AS percent_complete
FROM user_lesson_progress p;

-- Dashboard summary per user
CREATE VIEW v_user_dashboard AS
SELECT  u.user_id,
        u.full_name,
        u.skill_level,
        (SELECT COUNT(*) FROM user_lesson_progress p
          WHERE p.user_id = u.user_id AND p.status = 'completed')    AS lessons_completed,
        (SELECT COUNT(*) FROM user_lesson_progress p
          WHERE p.user_id = u.user_id AND p.status = 'in_progress')  AS lessons_in_progress,
        (SELECT ROUND(AVG(100.0 * a.score / NULLIF(a.max_score,0)),1)
           FROM quiz_attempts a WHERE a.user_id = u.user_id)         AS avg_quiz_percent,
        (SELECT COUNT(*) FROM user_badges b WHERE b.user_id = u.user_id) AS badges_earned
FROM users u;

-- Lessons with title in every language (join on language_id when querying)
CREATE VIEW v_lessons_localized AS
SELECT  l.lesson_id, l.slug, l.category_id, l.difficulty, l.estimated_minutes,
        t.language_id, t.title, t.description
FROM lessons l
JOIN lesson_translations t ON t.lesson_id = l.lesson_id
WHERE l.is_published = 1;

-- =====================================================================
-- SEED DATA
-- =====================================================================
INSERT INTO languages (code, name, native_name) VALUES
 ('en','English','English'),
 ('hi','Hindi','हिन्दी'),
 ('bn','Bengali','বাংলা'),
 ('ta','Tamil','தமிழ்'),
 ('te','Telugu','తెలుగు'),
 ('mr','Marathi','मराठी');

INSERT INTO categories (slug, icon, sort_order) VALUES
 ('communication','💬',1),
 ('digital-payments','💳',2),
 ('online-services','🏛️',3),
 ('device-basics','📱',4),
 ('productivity','📝',5),
 ('cybersecurity','🔒',6);

INSERT INTO category_translations (category_id, language_id, name, description) VALUES
 (1,1,'Communication','WhatsApp, email, video calls'),
 (1,2,'संचार','व्हाट्सऐप, ईमेल, वीडियो कॉल'),
 (2,1,'Digital Payments','UPI, QR codes, net banking'),
 (2,2,'डिजिटल भुगतान','यूपीआई, क्यूआर कोड, नेट बैंकिंग'),
 (3,1,'Online Services','Government and everyday services'),
 (3,2,'ऑनलाइन सेवाएँ','सरकारी और रोज़मर्रा की सेवाएँ'),
 (4,1,'Device Basics','Using your phone and computer'),
 (4,2,'डिवाइस की बुनियादी बातें','फ़ोन और कंप्यूटर का उपयोग'),
 (5,1,'Productivity','Documents, spreadsheets, calendars'),
 (5,2,'उत्पादकता','दस्तावेज़, स्प्रेडशीट, कैलेंडर'),
 (6,1,'Cybersecurity','Stay safe from scams and fraud'),
 (6,2,'साइबर सुरक्षा','धोखाधड़ी से सुरक्षित रहें');

-- Sample lessons
INSERT INTO lessons (category_id, slug, difficulty, estimated_minutes) VALUES
 (4,'turn-on-wifi','beginner',5),
 (1,'send-whatsapp-message','beginner',8),
 (2,'make-upi-payment','intermediate',12),
 (6,'spot-phishing-sms','beginner',10);

INSERT INTO lesson_translations (lesson_id, language_id, title, description) VALUES
 (1,1,'Turn on Wi-Fi','Connect your phone to a Wi-Fi network'),
 (1,2,'वाई-फ़ाई चालू करें','अपने फ़ोन को वाई-फ़ाई से जोड़ें'),
 (2,1,'Send a WhatsApp message','Send your first message'),
 (2,2,'व्हाट्सऐप संदेश भेजें','अपना पहला संदेश भेजें'),
 (3,1,'Make a UPI payment','Pay a shop using a QR code'),
 (3,2,'यूपीआई से भुगतान करें','क्यूआर कोड से दुकान को भुगतान करें'),
 (4,1,'Spot a phishing SMS','Identify fake bank messages'),
 (4,2,'फ़िशिंग एसएमएस पहचानें','नकली बैंक संदेश पहचानें');

INSERT INTO lesson_prerequisites VALUES (3,1), (3,2);

INSERT INTO lesson_steps (lesson_id, step_number, image_path) VALUES
 (1,1,'img/wifi_1.png'), (1,2,'img/wifi_2.png'), (1,3,'img/wifi_3.png');

INSERT INTO step_translations (step_id, language_id, title, instruction) VALUES
 (1,1,'Open Settings','Tap the gear icon on your home screen.'),
 (1,2,'सेटिंग्स खोलें','होम स्क्रीन पर गियर आइकन दबाएँ।'),
 (2,1,'Tap Wi-Fi','Find and tap the Wi-Fi option.'),
 (2,2,'वाई-फ़ाई दबाएँ','वाई-फ़ाई विकल्प ढूँढकर दबाएँ।'),
 (3,1,'Switch it on','Slide the switch to ON and pick your network.'),
 (3,2,'चालू करें','स्विच को ON करें और अपना नेटवर्क चुनें।');

INSERT INTO practice_scenarios (lesson_id, title, scenario_type, config_json) VALUES
 (1,'Practice: Wi-Fi settings','click_path',
  '{"expected_path":["settings","wifi","toggle_on"],"max_hints":3}');

-- Sample quiz
INSERT INTO quizzes (lesson_id, pass_percentage) VALUES (4, 60);
INSERT INTO questions (quiz_id, question_type) VALUES (1,'single_choice');
INSERT INTO question_translations (question_id, language_id, question_text, explanation) VALUES
 (1,1,'A message asks for your OTP to "unblock your account". What should you do?',
  'Banks never ask for OTP or PIN. Never share them.');
INSERT INTO options (question_id, is_correct) VALUES (1,0),(1,1),(1,0);
INSERT INTO option_translations (option_id, language_id, option_text) VALUES
 (1,1,'Share the OTP quickly'),
 (2,1,'Ignore it and never share the OTP'),
 (3,1,'Click the link in the message');

INSERT INTO badges (code, name, description, icon) VALUES
 ('FIRST_LESSON','First Step','Completed your first lesson','🌱'),
 ('SAFE_SURFER','Safe Surfer','Passed a cybersecurity quiz','🛡️'),
 ('PAYMENT_PRO','Payment Pro','Completed a payment practice','💰');
