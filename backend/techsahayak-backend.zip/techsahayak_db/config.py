"""Central settings. Every other file imports from here."""
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "techsahayak.db")
SQL_FILE = os.path.join(BASE_DIR, "techsahayak.sql")
DEFAULT_LANGUAGE_ID = 1  # English
