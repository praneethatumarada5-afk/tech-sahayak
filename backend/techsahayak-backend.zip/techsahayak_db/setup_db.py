"""Run ONCE (or whenever you want a fresh database): python setup_db.py"""
import os
import sqlite3
from config import DB_PATH, SQL_FILE

if os.path.exists(DB_PATH):
    os.remove(DB_PATH)

conn = sqlite3.connect(DB_PATH)
with open(SQL_FILE, encoding="utf-8") as f:
    conn.executescript(f.read())
conn.commit()
count = conn.execute(
    "SELECT COUNT(*) FROM sqlite_master WHERE type='table'").fetchone()[0]
conn.close()
print(f"Database created with {count} tables -> {DB_PATH}")
