"""Reading learning content (categories, lessons, steps) in the user's language."""
from database import get_connection


def get_languages():
    conn = get_connection()
    rows = conn.execute("SELECT * FROM languages WHERE is_active=1").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_categories(language_id=1):
    conn = get_connection()
    rows = conn.execute("""
        SELECT c.category_id, c.slug, c.icon,
               COALESCE(t.name, e.name) AS name,
               COALESCE(t.description, e.description) AS description
        FROM categories c
        LEFT JOIN category_translations t ON t.category_id=c.category_id AND t.language_id=?
        LEFT JOIN category_translations e ON e.category_id=c.category_id AND e.language_id=1
        ORDER BY c.sort_order""", (language_id,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_lessons(language_id=1, category_id=None, difficulty=None):
    """Falls back to English if a translation is missing."""
    sql = """
        SELECT l.lesson_id, l.slug, l.category_id, l.difficulty,
               l.estimated_minutes,
               COALESCE(t.title, e.title) AS title,
               COALESCE(t.description, e.description) AS description
        FROM lessons l
        LEFT JOIN lesson_translations t ON t.lesson_id=l.lesson_id AND t.language_id=?
        LEFT JOIN lesson_translations e ON e.lesson_id=l.lesson_id AND e.language_id=1
        WHERE l.is_published=1"""
    params = [language_id]
    if category_id:
        sql += " AND l.category_id=?"
        params.append(category_id)
    if difficulty:
        sql += " AND l.difficulty=?"
        params.append(difficulty)
    conn = get_connection()
    rows = conn.execute(sql, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_lesson_steps(lesson_id, language_id=1):
    conn = get_connection()
    rows = conn.execute("""
        SELECT s.step_id, s.step_number, s.image_path, s.audio_path,
               COALESCE(t.title, e.title) AS title,
               COALESCE(t.instruction, e.instruction) AS instruction
        FROM lesson_steps s
        LEFT JOIN step_translations t ON t.step_id=s.step_id AND t.language_id=?
        LEFT JOIN step_translations e ON e.step_id=s.step_id AND e.language_id=1
        WHERE s.lesson_id=? ORDER BY s.step_number""",
        (language_id, lesson_id)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def is_lesson_unlocked(user_id, lesson_id):
    """A lesson is unlocked when ALL its prerequisites are completed."""
    conn = get_connection()
    missing = conn.execute("""
        SELECT COUNT(*) FROM lesson_prerequisites p
        WHERE p.lesson_id=? AND NOT EXISTS (
            SELECT 1 FROM user_lesson_progress u
            WHERE u.user_id=? AND u.lesson_id=p.prerequisite_lesson_id
              AND u.status='completed')""", (lesson_id, user_id)).fetchone()[0]
    conn.close()
    return missing == 0


def get_practice_scenarios(lesson_id):
    conn = get_connection()
    rows = conn.execute("SELECT * FROM practice_scenarios WHERE lesson_id=?",
                        (lesson_id,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]
